% 设置文件夹路径
folder_path = '/Users/zhj/Desktop/Patient_timepoints_BN246'; % 替换为你的文件夹路径

% 获取文件夹中所有.mat文件
mat_files = dir(fullfile(folder_path, '*.mat'));

% 遍历每个文件
for k = 1:length(mat_files)
    % 构造文件完整路径
    file_path = fullfile(folder_path, mat_files(k).name);
    
    % 加载 .mat 文件数据
    data = load(file_path);
    
    % 保存文件时附加 -v7.3 选项，指定保存为 MATLAB 7.3 格式
    save(file_path, '-struct', 'data', '-v7.3');
end